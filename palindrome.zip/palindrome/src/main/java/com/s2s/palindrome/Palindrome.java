package com.s2s.palindrome;

public class Palindrome
{
    public boolean isPalindrome(String inputString)
    {
        boolean result = false;

        if (inputString.length() == 0)
        {
            result = true;
        }
        return result;
    }
}
